'''
@Time : 2021/1/15 11:32
@Author : WGS
@remarks : GBDT+LR
https://blog.csdn.net/qq_42363032/article/details/112756687
'''

import numpy as np

np.random.seed(10)

import matplotlib.pyplot as plt

from sklearn.datasets import make_classification, make_regression
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import (RandomTreesEmbedding, RandomForestClassifier,
                              GradientBoostingClassifier, GradientBoostingRegressor)
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from sklearn.pipeline import make_pipeline

# 树的数量，默认10个
n_estimator = 10

# 构造分类数据
X, y = make_regression(n_samples=1000,n_features=20)
# 划分数据集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5)

X_train, X_train_lr, y_train, y_train_lr = train_test_split(X_train, y_train, test_size=0.5)

dt = DecisionTreeRegressor(max_leaf_nodes=18)
dt.fit(X_train, y_train)
# 树模型apply返回的是该样本最后落到的叶子节点的index的数组
b = dt.apply(X_train)
y_pred_grd = dt.predict(X_train)
# 建立并训练onehot编码器（即预先告诉onehot，有哪些类别，也就是叶子节点的index）
grd_enc = OneHotEncoder()
grd_enc.fit(dt.apply(X_train_lr).reshape(len(X_train_lr), 1))
# 转换为稀疏向量，特征维度大小等于数的叶子节点数。返回是一个稀疏矩阵
c= grd_enc.transform(dt.apply(X_train_lr).reshape(250,1))

grd = GradientBoostingRegressor(n_estimators=10)   # GBDT建模

grd_enc = OneHotEncoder()   # onehot

grd_lm = LogisticRegression()   # LR

grd.fit(X_train, y_train)

# grd.apply(X_train)[:, :, 0]  # 返回叶子索引   [:, :, 0]：原来是三维，变成2维
grd_enc.fit(grd.apply(X_train))
b = grd.apply(X_train)

grd_lm.fit(grd_enc.transform(grd.apply(X_train_lr)), y_train_lr)
c= grd_enc.transform(grd.apply(X_train_lr)[:, :, 0])
y_pred_grd_lm = grd_lm.predict_proba(grd_enc.transform(grd.apply(X_test)[:, :, 0]))[:, 1]
fpr_grd_lm, tpr_grd_lm, _ = roc_curve(y_test, y_pred_grd_lm)

y_pred_grd = grd.predict_proba(X_test)[:, 1]
fpr_grd, tpr_grd, _ = roc_curve(y_test, y_pred_grd)



plt.figure(2)
plt.xlim(0, 0.2)
plt.ylim(0.8, 1)
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr_grd, tpr_grd, label='GBDT')
plt.plot(fpr_grd_lm, tpr_grd_lm, label='GBDT + LR')
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve (zoomed in at top left)')
plt.legend(loc='best')
plt.show()


