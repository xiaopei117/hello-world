alter table dm_as.dm_sku_information_info_df drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
insert overwrite table dm_as.dm_sku_information_info_df partition (inc_day=$[time(yyyyMMdd,-1d)])

select t1.company_code,
	   t2.company_name,
	   t1.sku_no,
	   t1.sku_name,
	   t1.item_classify1,    -- 一级分类
	   t1.item_classify2,	 -- 二级分类
	   t1.item_classify3,	 -- 三级分类
	   t1.first_inbound_date, -- 首次入库时间
	   t1.shelf_life, -- 有效期，有效期天数
	   t1.update_time --更新时间
	from
	dm_elog_dwh.dim_sku as t1  -- 非分区表
	left join 
	(
	select distinct company_code,company_name
		   from dm_elog_dwh.dim_company_warehouse -- 非分区表
	) as t2    -- 查找货主编码对应的货主名称
	on t1.company_code = t2.company_code
	and t1.is_present != 1 -- 排除赠品
	and t1.is_virtual_product !=1;  -- 排除虚拟物品
	