alter table dm_as.dm_intransit_dtl_di drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
insert overwrite table dm_as.dm_intransit_dtl_di partition (inc_day=$[time(yyyyMMdd,-1d)])


select
	s1.company_code,
	s3.company_name,
	s1.receipt_id, -- 入库单号
	s2.erp_order,  -- 运单号
	s1.warehouse_code, -- 仓库编码
	s3.warehouse_name, -- 仓库名称
	s1.sku_no, 
	s4.sku_name,
	s1.plan_qty, -- 应收数量
	s1.qty_um, --数量单位
	s2.order_date, -- 订单日期
	s2.scheduled_receipt_date, -- 预计收获日期
	s2.sf_order_type, -- 订单类型
	s1.update_tm -- 统计时间
	from 
--------- detail 
(
  select
	receipt_header_id,
	warehouse_code,
	company_code,
	erp_order_line_num,
	receipt_id,
	sku_no,
	plan_qty,
	actual_qty,
	qty_um,   	   -- 数量单位
	inventory_status,-- 库存状态
	update_tm
  from
  (
    select
      receipt_header_id,
      warehouse_code,
      company_code,
      erp_order_line_num,
      receipt_id,
      sku_no,
      plan_qty,
      actual_qty,
      qty_um,
      -- 数量单位
      inventory_status,
      -- 库存状态
      update_tm,
      row_number() over(partition by receipt_header_id,warehouse_code,company_code,erp_order_line_num,receipt_id,sku_no order by update_tm desc) as rk
    from
      ods_oms.wom_tb_receipt_detail
	  where inc_day = $[time(yyyyMMdd,-1d)]
		and actual_qty =0  -- 实际入库数量为0  在途表
  ) as t
where t.rk = 1
) as s1 
 left join 
 ------ header 
 (
  select 
	   id,
	   company_code,
	   warehouse_code,
	   receipt_id,
	   erp_order,
	   scheduled_receipt_date, -- 预计到达时间
	   erp_order_type, -- 客户订单类型
	   sf_order_type, -- 顺丰订单类型
	   close_date, -- 关单时间
	   status,     -- 状态
	   update_tm,  -- 修改时间
	   ver,         -- 版本号
	   order_date
  from 
	(
	 select 
	   id,
	   company_code,
	   warehouse_code,
	   receipt_id,
	   erp_order,
	   scheduled_receipt_date, -- 预计到达时间
	   erp_order_type, -- 客户订单类型
	   sf_order_type, -- 顺丰订单类型
	   close_date, -- 关单时间
	   status,     -- 状态
	   update_tm,  -- 修改时间
	   ver,        -- 版本号
	   order_date,
	   row_number() over(partition by company_code,company_code,receipt_id,erp_order order by ver desc) as rk 
	   from ods_oms.wom_tb_receipt_header
	   where inc_day = $[time(yyyyMMdd,-1d)]
	) as t 
	where t.rk = 1
   ) as s2 
  on s1.receipt_header_id = s2.id
  and s1.warehouse_code = s2.warehouse_code
  and s1.company_code   = s2.company_code
  and s1.receipt_id  = s2.receipt_id
  
  left join
  (		
   select distinct company_code,company_name,warehouse_code,warehouse_name
       from dm_elog_dwh.dim_company_warehouse -- 非分区表
   ) as s3
  
  on s1.company_code = s3.company_code
  and s1.warehouse_code = s3.warehouse_code
  
  left join 
  (
	select sku_no,max(sku_name) as sku_name from dm_elog_dwh.dim_sku -- 非分区表
		   group by sku_no
  ) as s4
  
  on s1.sku_no = s4.sku_no
  
  left join 
  (
	select receipt_id,max(receive_time) as receive_time from gdl.mm_receipt_item_info 
		   where inc_day = $[time(yyyyMMdd,-1d)]
		   group by receipt_id
  ) as s5
  on s1.receipt_id = s5.receipt_id
  