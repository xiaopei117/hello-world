alter table dm_as.dm_company_sale_zipper_df drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
insert overwrite table dm_as.dm_company_sale_zipper_df partition (inc_day=$[time(yyyyMMdd,-1d)])

select t.company_name,
	   t.company_code,
	   t.industry_type,
	   t.qty as qty_sale, -- 销量
	   row_number() over(order by t.qty desc) as qty_rank, --销量排名
	   ' ' as is_calulate
	from
	(
	select  
		t1.company_name,
		t1.company_code,
		t1.industry_type,
		sum(t2.qty_ordered) as qty
		from 
			ods_oms.wom_tb_company as t1  -- 货主代码表
			inner join dm_as.dm_sale_order_dtl_df as t2  -- 销售订单明细全量表
			on t1.company_code = t2.company_code
		where t2.inc_day=$[time(yyyyMMdd,-1d)]
		  and t1.inc_day=$[time(yyyyMMdd,-1d)]
		    group by t1.company_name,
		             t1.company_code,
		             t1.industry_type
	) as t;

