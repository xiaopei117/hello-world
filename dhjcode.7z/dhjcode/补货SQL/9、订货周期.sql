truncate table tmp_dm_as.order_cycle;
insert overwrite table tmp_dm_as.order_cycle ----- 临时表，用来导入数据
select
	s1.company_code,
	s3.company_name,
	s1.warehouse_code, -- 仓库编码
	s3.warehouse_name, -- 仓库名称
	s1.sku_no, 
	s4.sku_name,
	s1.plan_qty, -- 应收数量
	s2.order_date, -- 订单日期
	s2.scheduled_receipt_date -- 预计收获日期
	from 
--------- detail 
(
  select
	receipt_header_id,
	warehouse_code,
	company_code,
	erp_order_line_num,
	receipt_id,
	sku_no,
	plan_qty,
	actual_qty,
	qty_um,   	   -- 数量单位
	inventory_status,-- 库存状态
	update_tm
  from
  (
    select
      receipt_header_id,
      warehouse_code,
      company_code,
      erp_order_line_num,
      receipt_id,
      sku_no,
      plan_qty,
      actual_qty,
      qty_um,
      -- 数量单位
      inventory_status,
      -- 库存状态
      update_tm,
      row_number() over(partition by receipt_header_id,warehouse_code,company_code,erp_order_line_num,receipt_id,sku_no order by update_tm desc) as rk
    from
      ods_oms.wom_tb_receipt_detail
	  where inc_day >= $[time(yyyyMMdd,-90d)]
	    and inc_day <= $[time(yyyyMMdd)]
	--	and actual_qty >0  -- 实际入库数量大于0  入库表
  ) as t
where t.rk = 1
) as s1 
 left join 
 ------ header 
 (
  select 
	   id,
	   company_code,
	   warehouse_code,
	   receipt_id,
	   erp_order,
	   scheduled_receipt_date, -- 预计到达时间
	   erp_order_type, -- 客户订单类型
	   sf_order_type, -- 顺丰订单类型
	   close_date, -- 关单时间
	   status,     -- 状态
	   update_tm,  -- 修改时间
	   ver,         -- 版本号
	   order_date
  from 
	(
	 select 
	   id,
	   company_code,
	   warehouse_code,
	   receipt_id,
	   erp_order,
	   scheduled_receipt_date, -- 预计到达时间
	   erp_order_type, -- 客户订单类型
	   sf_order_type, -- 顺丰订单类型
	   close_date, -- 关单时间
	   status,     -- 状态
	   update_tm,  -- 修改时间
	   ver,        -- 版本号
	   order_date,
	   row_number() over(partition by company_code,company_code,receipt_id,erp_order order by ver desc) as rk 
	   from ods_oms.wom_tb_receipt_header
	   where inc_day >= $[time(yyyyMMdd,-90d)]
	    and inc_day <= $[time(yyyyMMdd)]
	) as t 
	where t.rk = 1
   ) as s2 
  on s1.receipt_header_id = s2.id
  and s1.warehouse_code = s2.warehouse_code
  and s1.company_code   = s2.company_code
  and s1.receipt_id  = s2.receipt_id
  
  left join
  (		
   select distinct company_code,company_name,warehouse_code,warehouse_name
       from dm_elog_dwh.dim_company_warehouse -- 非分区表
   ) as s3
  
  on s1.company_code = s3.company_code
  and s1.warehouse_code = s3.warehouse_code
  
  left join 
  (
	select sku_no,max(sku_name) as sku_name from dm_elog_dwh.dim_sku -- 非分区表
		   group by sku_no
  ) as s4
    
  on s1.sku_no = s4.sku_no;
 ------------------------------------------------------------------------------------------以上导入数据到临时表-----------------
 -- -----------------------------------------------------计算平均提前期与平均需求量
alter table dm_as.dm_order_cycle_sum_wi drop partition (inc_week=$[time(yyyyMMdd)]);
insert overwrite table dm_as.dm_order_cycle_sum_wi partition (inc_week=$[time(yyyyMMdd)])

  select s1.company_code,
		 s1.company_name,
		 s1.warehouse_code,
		 s1.warehouse_name,
		 s1.sku_no,
		 s1.sku_name,
		 s1.order_nums,   -- 需求次数
		 s1.avg_plan_qty, -- 平均需求量
		 s1.cv, -- 变异系数
		 s1.avg_day_pre,  -- 提前期均值天
	--	 s1.avg_hour_pre,
		 s2.avg_day_order, -- 平均订货周期_天
	--	 s2.avg_hour_order,
		 case when order_nums <= 3 	then '极端低频'
			  when order_nums >3 and cv < 5 and s1.avg_plan_qty <= 1 then '极端小'
			  when order_nums >3 and cv < 0.7 and s2.avg_day_order<=1.32 and s1.avg_plan_qty > 1  then '高频稳定'
			  when order_nums >3 and cv >= 0.7 and s2.avg_day_order<=1.32 and s1.avg_plan_qty > 1 then '高频不稳定'
			  when order_nums >3 and cv < 0.7 and s2.avg_day_order>1.32  and s1.avg_plan_qty > 1  then '低频稳定'
			  when order_nums >3 and cv >= 0.7 and s2.avg_day_order>1.32  and s1.avg_plan_qty > 1 then '低频不稳定'
			  when order_nums >3 and cv >= 5 then '极端不稳定'
			  end as feature
 	    from 
 (select company_code,
		company_name,
		warehouse_code,
		warehouse_name,
		sku_no,
		sku_name,
		count(order_date) as order_nums, -- 需求次数
		avg(plan_qty) as avg_plan_qty, -- 平均需求量
		stddev_samp(plan_qty) / avg(plan_qty) as cv, -- 变异系数
		avg((unix_timestamp(scheduled_receipt_date) - unix_timestamp(order_date))/86400) as avg_day_pre -- 提前期均值天
	--	avg((unix_timestamp(scheduled_receipt_date) - unix_timestamp(order_date))/3600) as avg_hour_pre -- 提前期均值小时
		from tmp_dm_as.order_cycle 
		group by 
		company_code,
		company_name,
		warehouse_code,
		warehouse_name,
		sku_no,
		sku_name
  ) as s1 
  left join 
  (
  select t1.company_code,
		 t1.company_name,
		 t1.warehouse_code,
		 t1.warehouse_name,
		 t1.sku_no,
		 t1.sku_name, 
		 avg((unix_timestamp(t2.order_date) - unix_timestamp(t1.order_date))/86400) as avg_day_order  -- 平均订货周期_天
	--	 avg((unix_timestamp(t2.order_date) - unix_timestamp(t1.order_date))/3600) as avg_hour_order -- 平均订货周期_小时
		 from 
  (select company_code,
		 company_name,
		 warehouse_code,
		 warehouse_name,
		 sku_no,
		 sku_name,
		 order_date,
		 row_number() over(partition by company_code,company_name,warehouse_code,warehouse_name,sku_no,sku_name order by order_date) as rk_1
		 from tmp_dm_as.order_cycle
	) as t1 
	left join 
	(select company_code,
		 company_name,
		 warehouse_code,
		 warehouse_name,
		 sku_no,
		 sku_name,
		 order_date,
		 row_number() over(partition by company_code,company_name,warehouse_code,warehouse_name,sku_no,sku_name order by order_date) as rk_2
		 from tmp_dm_as.order_cycle
	) as t2 
	on t1.company_code =t2.company_code
	and  t1.company_name = t2.company_name
	and   t1.warehouse_code = t2.warehouse_code
	and   t1.warehouse_name = t2.warehouse_name
	and   t1.sku_no = t2.sku_no
	and   t1.sku_name = t2.sku_name
	and   t1.rk_1 + 1 = t2.rk_2
	where t2.rk_2 is not null 
	group by 
		 t1.company_code,
		 t1.company_name,
		 t1.warehouse_code,
		 t1.warehouse_name,
		 t1.sku_no,
		 t1.sku_name
	) as s2 
	on s1.company_code = s2.company_code
	and s1.company_name = s2.company_name
	and s1.warehouse_code = s2.warehouse_code
	and s1.warehouse_name = s2.warehouse_name
	and s1.sku_no = s2.sku_no 
	and s1.sku_name = s2.sku_name;
	
		 
	
	
		 
		 

		