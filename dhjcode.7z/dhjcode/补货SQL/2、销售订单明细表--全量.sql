alter table dm_as.dm_sale_order_dtl_df drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
alter table dm_as.dm_sale_order_dtl_df drop partition (inc_day=$[time(yyyyMMdd,-4d)]);
insert overwrite table dm_as.dm_sale_order_dtl_df partition (inc_day=$[time(yyyyMMdd,-1d)])
select s2.company_code,
	   s2.company_name,
	   s2.shipment_id,
	   s2.shipment_date,	   
	   s2.waybill_no,
	   s2.warehouse_code,
	   s2.warehouse_name,
	   s2.sku_no,
	   s2.sku_name,
	   s2.sku_qty,     -- 商品数量	   
	   s2.order_type_code,
	   s2.order_type_name,
	   s2.qty_ordered, -- 数量单位
	   s2.order_time, -- 下单时间
	   s2.order_no, -- 富勒单号
	   s2.uom, -- 单位
	   s2.orderlineno,
	   s2.order_end_tm
	   from 
(select s1.company_code,
	   s1.company_name,
	   s1.shipment_id,
	   s1.shipment_date,	   
	   s1.waybill_no,
	   s1.warehouse_code,
	   s1.warehouse_name,
	   s1.sku_no,
	   s1.sku_name,
	   s1.sku_qty,     -- 商品数量	   
	   s1.order_type_code,
	   s1.order_type_name,
	   s1.qty_ordered, -- 数量单位
	   s1.order_time, -- 下单时间
	   s1.order_no, -- 富勒单号
	   s1.uom, -- 单位
	   s1.orderlineno,
	   s1.order_end_tm,
	   row_number() over(partition by company_code,warehouse_code,waybill_no,sku_no,orderlineno order by order_end_tm desc) as rn 
	   from 
(select 
	   company_code,
	   company_name,
	   shipment_id,
	   shipment_date,	   
	   waybill_no,
	   warehouse_code,
	   warehouse_name,
	   sku_no,
	   sku_name,
	   sku_qty,     -- 商品数量	   
	   order_type_code,
	   order_type_name,
	   qty_ordered, -- 数量单位
	   order_time, -- 下单时间
	   order_no, -- 富勒单号
	   uom, -- 单位
	   orderlineno,
	   order_end_tm	   
	from dm_as.dm_sale_order_dtl_df
	where inc_day = $[time(yyyyMMdd,-2d)]  
	
union all   ----------- 今日全量 = 昨日全量 + 今日增量 

select
	   company_code,
	   company_name,
	   shipment_id,
	   shipment_date,	   
	   waybill_no,
	   warehouse_code,
	   warehouse_name,
	   sku_no,
	   sku_name,
	   sku_qty,     -- 商品数量	   
	   order_type_code,
	   order_type_name,
	   qty_ordered, -- 数量单位
	   order_time, -- 下单时间
	   order_no, -- 富勒单号
	   uom, -- 单位
	   orderlineno,
	   order_end_tm
	from dm_as.dm_salr_order_dtl_di
	where inc_day = $[time(yyyyMMdd,-1d)]
) as s1 
) as s2
where s2.rn = 1