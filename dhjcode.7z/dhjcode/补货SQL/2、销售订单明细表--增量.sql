alter table dm_as.dm_salr_order_dtl_di drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
insert overwrite table dm_as.dm_salr_order_dtl_di partition (inc_day=$[time(yyyyMMdd,-1d)])
select
	   company_code,
	   company_name,
	   shipment_id,
	   shipment_date,	   
	   waybill_no,
	   warehouse_code,
	   warehouse_name,
	   sku_no,
	   sku_name,
	   sum(sku_qty) as sku_qty,     -- 商品数量	   
	   order_type_code,
	   order_type_name,
	   sum(qty_ordered) as qty_ordered, -- 数量单位
	   order_time, -- 下单时间
	   order_no, 
	   uom,
	   orderlineno,
	   order_end_tm
	from 
(select 
	   company_code,
	   company_name,
	   shipment_id,
	   waybill_no,
	   warehouse_code,
	   warehouse_name,
	   sku_no,
	   sku_name,
	   sku_qty,
	   qty_ordered,
	   order_time,
	   shipment_date,
	   order_type_code,
	   order_type_name,
	   order_no, -- 富勒单号
	   uom, -- 单位
	   inc_day,
	   orderlineno,
	   order_end_tm,
	   row_number() over(partition by company_code,warehouse_code,waybill_no,sku_no,orderlineno order by order_end_tm desc) as rn 
	   from 
	   gdl.mm_shipment_item_info
	   where  inc_day = $[time(yyyyMMdd,-1d)]
)   as t 
	where t.rn = 1
	group by 
	   company_code,
	   company_name,
	   shipment_id,
	   shipment_date,	   
	   waybill_no,
	   warehouse_code,
	   warehouse_name,
	   sku_no,
	   sku_name,
	   order_type_code,
	   order_type_name,
	   order_time, -- 下单时间
	   order_no, 
	   uom,
	   orderlineno,
	   order_end_tm
	   
