alter table dm_as.dm_inventory_info_df drop partition (inc_day=$[time(yyyyMMdd,-1d)]);
insert overwrite table dm_as.dm_inventory_info_df partition (inc_day=$[time(yyyyMMdd,-1d)])

select 
	t1.company_code,
	t2.company_name,
	t1.warehouse_code,
	t2.warehouse_name,
	t1.sku_no,
	t3.sku_name,
	t1.total_qty, -- 库存数量
	t1.data_date,  -- 库存日期
	t1.inventory_status, -- 库存状态
	'null' as s1,
	'null' as s2,
	'null' as s3
 	from 
	dm_elog_dwh.dwh_inventory_item_detail_info  as t1    -- 库存商品明细表 分区表
	left join 
	(
	 select distinct company_code,company_name,warehouse_code,warehouse_name
       from dm_elog_dwh.dim_company_warehouse
	  ) as t2    -- 查找仓库、货主编码对应的仓库、货主名称 -- 非分区表
	on t1.company_code = t2.company_code
	and t1.warehouse_code = t2.warehouse_code
	
	left join 
	(
	select sku_no,max(sku_name) as sku_name from dm_elog_dwh.dim_sku -- 非分区表
		   group by sku_no
	) as t3 
	on  t1.sku_no = t3.sku_no
	where t1.inc_day = 	$[time(yyyyMMdd,-1d)];
	