from sklearn import linear_model
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import numpy as np

class LR():
    def __init__(self, data_x, data_y, init_weight=None, init_bias=None):
        self.data_x = data_x
        self.data_y = data_y
        self.n_feature = len(data_x[0])
        if(init_weight is None):
            self.weights = np.random.rand(self.n_feature, 1)
        if(init_bias is None):
            self.bias = np.random.rand(1)[0]

    def sigmoid(self,x):
        return 1.0 / (1.0 + np.exp(-x))

    def predict(self, x, thred=0.5):
        w, b = self.weights, self.bias
        y_prob = self.sigmoid(x.dot(w) + b)
        y_class = np.zeros_like(y_prob)
        y_class[y_prob>thred] = 1
        return y_class, y_prob

    def test(self, x=None, y=None, thred=0.5):
        if(x is None):
            x, y = self.data_x, np.reshape(self.data_y, (len(self.data_y),1))
        y_predict = self.predict(x, thred)
        oa = accuracy_score(y, y_predict)
        auc = roc_auc_score(y, y_predict)
        print(" ====== test result =========")
        print("OA",oa,"AUC",auc)

    def gradAscent(self, alpha = 0.001, epochs = 100, lamda = 0.1):
        dataMatrix, labelMat = self.data_x, self.data_y
        if(not isinstance(dataMatrix, np.ndarray)):
            dataMatrix = dataMatrix.to_numpy()
        if(not isinstance(labelMat, np.ndarray)):
            labelMat = labelMat.to_numpy()
        labelMat = np.reshape(labelMat, (len(labelMat), 1))
        m, n = dataMatrix.shape
        weights = np.random.rand(n, 1)
        bias = np.random.rand(1)[0]
        ma = 0
        v = 0
        mse_train = []
        for cycle in range(1,epochs):
            vector = self.sigmoid(dataMatrix.dot(weights) + bias)
            error = labelMat - vector
            mse_train.append(np.average(pow(error, 2)))
            # print((dataMatrix.T).dot(error)/m)
            grad = np.array([(dataMatrix.T).dot(error)/m + 2 * lamda * weights, np.sum(error)/m], dtype=object)
            ma = 0.9 * ma + 0.1 * grad
            v = 0.999 * v + 0.001 * pow(grad,2)
            ma_hat = ma / (1 - 0.9**cycle)
            v_hat = v / (1 - 0.999**cycle)
            update = alpha * ma_hat / (np.array(list(map(lambda x: np.sqrt(x),v_hat))) + 1e-8)
            weights = weights + update[0]
            bias = bias + update[1]
            # weights = weights + alpha * (dataMatrix.T).dot(error)
        self.weights = weights
        self.bias = bias
        self.mse_train = mse_train
        # return weights, bias, mse_train

    def train_OLS(self):
        x = self.data_x
        y = self.data_y
        model = linear_model.LinearRegression()
        model.fit(x, y)
        t0, t1 = model.intercept_[0], model.coef_[0][0]
        print('打印b', t0)
        print('打印a', t1)
        re = model.predict(x)
        return re

    def visualize_model(self):
        if(self.n_feature !=2):
            print("only can show the 2-dimensional")
            return
        w = self.weights
        b = self.bias
        x1 = np.array([min(self.data_x[:,0]), max(self.data_x[:,0])])
        x2 = (-b - x1 * w[0][0]) / w[1][0]

        plt.figure(), plt.scatter(data_x[data_y == 0, 0], data_x[data_y == 0, 1], color='green'),
        plt.scatter(data_x[data_y == 1, 0], data_x[data_y == 1, 1], color='blue'), \
        plt.plot(x2, x1, color='red'), plt.show()

if __name__ == '__main__':
    data_lr = np.load("data_lr_train.npy")
    data_x = data_lr[:,:2]
    scaler = MinMaxScaler()
    data_x = scaler.fit_transform(data_x)
    data_y = data_lr[:,2]
    lr = LR(data_x, data_y)
    lr.gradAscent(alpha=0.01,epochs=500, lamda=0.1)
    lr.visualize_model()
    # lr.test()
    plt.figure(), plt.plot(lr.mse_train), plt.show()

    # y, y_hat = 1, 1
    # L = -y*np.log(y_hat) - (1-y)*np.log(1-y_hat)
    # grad_w = X * (sigmoid - Y)
    # grad_b = (sigmoid - Y)
    #
    # def lf(data_x):
    #     return
    #
    # n_feature = 2
    # n_sample = 100
    # data_x = np.random.randn(n_sample, n_feature)
    # data_y = np.random.randn(n_sample, 1)
    #
    #
    # alpha = 0.001
    # epochs = 100
    # m, v = 0, 0
    # beta1, beta2 = 0.9, 0.999
    # weights = np.random.randn(n_feature, 1)
    # bias = np.random.randn(1)[0]
    # for cycle in range(epochs):
    #     err = lr(data_x) - data_y
    #     grad_w = data_x.T * err
    #     grad_b = err
    #     grad = np.array([grad_w, grad_b], dtype=object)
    #     m = beta1*m + (1-beta1)*grad
    #     v = beta2*v + (1-beta2)*pow(grad, 2)
    #     m_hat = m/(1-beta1**cycle)
    #     v_hat = v / (1-beta2**cycle)
    #     update = alpha * m_hat / (np.array(list(map(lambda x: np.sqrt(x),v_hat))) + 1e-8)
    #     weights -= update[0]
    #     bias -= update[1]



