import numpy as np
import matplotlib.pyplot as plt
def topKFrequent(nums, k):
    """
    :type nums: List[int]
    :type k: int
    :rtype: List[int]
    """
    hashmap = {}
    for n in nums:
        if (n in hashmap):
            hashmap[n] += 1
        else:
            hashmap[n] = 1
    arr = [[key, hashmap[key]] for key in hashmap]
    arr.sort(key=lambda x: x[1])
    arr = arr[::-1][:k]
    res = [x[0] for x in arr]
    return res

def distance(a, b):
    return np.sqrt(np.sum(pow(a-b,2)))


def knn(k, data_x, data_y, predicts):
    data_y = np.reshape(data_y, (len(data_y), 1))
    data = list(np.concatenate((data_x, data_y), axis=1))
    res = []
    for c in predicts:
        a = [[distance(d[:-1], c), d[:-1], d[-1]] for d in data]
        a.sort(key=lambda x:x[0])
        select_c = [x[-1] for x in a[:k]]
        pred = topKFrequent(select_c, k=1)
        res.append(pred)

    return res
if __name__ == "__main__":
    data_lr = np.load("data_lr_train.npy")
    data_x = data_lr[:,:-1]
    data_y = data_lr[:,-1]
    c = np.array([[7,3], [2,6]])
    res = knn(30, data_x,data_y, c)
    print(res)
    plt.figure(), plt.scatter(data_x[data_y == 0, 0], data_x[data_y == 0, 1], color='green'),
    plt.scatter(data_x[data_y == 1, 0], data_x[data_y == 1, 1], color='blue'), \
    plt.scatter(c[0], c[1], color='red'), plt.show()

