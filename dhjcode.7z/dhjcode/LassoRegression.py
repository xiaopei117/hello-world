import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
M = 3 #变量个数+1 变量加 偏移项b， 一个3个参数
N = 50 #样本个数
#随机生成两个属性的N个样本
feature1 = np.random.rand(N)*10
feature2 = np.random.rand(N)*10
splt = np.ones((1, N))
#
temp_X1 = np.row_stack((feature1, feature2))
temp_X = np.vstack((temp_X1, splt))
X_t = np.mat(temp_X)
X = X_t.T
temp_Y = np.random.rand(N)*10
Y_t = np.mat(temp_Y)
Y = Y_t.T
#画样本散点图
fig = plt.figure()
ax1 = Axes3D(fig)
ax1.scatter(feature1, feature2, temp_Y)
######
def errors(X, Y, Omega) :
    err = (X*Omega - Y).T*(X*Omega - Y)
    return err
'''
 下面是坐标下降法
 https://www.cnblogs.com/liudianfengmang/p/12811642.html
'''
def lasso_regression(X, Y, lambd, threshold):
    #
    Omega = np.mat(np.zeros((M, 1)))
    err = errors(X, Y, Omega)
    counts = 0          #统计迭代次数
    # 使用坐标下降法优化回归系数Omega
    while err > threshold:
        counts += 1
        for k in range(M):
            # 计算常量值z_k和p_k
            z_k = (X[:, k].T*X[:, k])[0, 0]
            p_k = 0
            for i in range(N):
                p_k += X[i, k]*(Y[i, 0] - sum([X[i, j]*Omega[j, 0] for j in range(M) if j != k]))
            if p_k < -lambd/2:
                w_k = (p_k + lambd/2)/z_k
            elif p_k > lambd/2:
                w_k = (p_k - lambd/2)/z_k
            else:
                w_k = 0
            Omega[k, 0] = w_k
        err_prime = errors(X, Y, Omega)
        delta = abs(err_prime - err)[0, 0]
        err = err_prime
        print('Iteration: {}, delta = {}'.format(counts, delta))
        if delta < threshold:
            break
    return Omega
#求Omega
lambd = 10.0
threshold = 0.1
Omega = lasso_regression(X, Y, lambd, threshold)
#画分回归平面
xx = np.linspace(0,10, num=50)
yy = np.linspace(0,10, num=50)
xx_1, yy_1 = np.meshgrid(xx, yy)
Omega_h = np.array(Omega.T)
zz_1 = Omega_h[0, 0]*xx_1 + Omega_h[0, 1]*yy_1 + Omega_h[0, 2]
ax1.plot_surface(xx_1, yy_1, zz_1, alpha= 0.6, color= "r")
plt.show()

'''
    下面是近端梯度下降法
    https://blog.csdn.net/DS_agent/article/details/106340777
'''

from itertools import cycle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import lasso_path, enet_path
from sklearn import datasets
from copy import copy

X = np.random.randn(100,10)
y = np.dot(X,[1,2,3,4,5,6,7,8,9,10])

def f(X, y, w):
    n_samples, _ = X.shape
    tmp = y - np.dot(X, w)
    return 2 * np.dot(tmp, tmp) / n_samples


def objective(X, y, w, lmbd):
    n_samples, _ = X.shape
    tmp = y - np.dot(X, w)
    obj_v = 2 * np.dot(tmp, tmp) / n_samples + lmbd * np.sum(np.abs(w))
    return obj_v


def LASSO_proximal_gradient(X, y, lmbd, L=1, max_iter=1000, tol=1e-4):
    beta = 0.5  # used to update L for finding proper step size
    n_samples, n_features = X.shape
    w = np.empty(n_features, dtype=float)
    w_prev = np.empty(n_features, dtype=float)  # store the old weights
    xty_N = np.dot(X.T, y) / n_samples
    xtx_N = np.dot(X.T, X) / n_samples
    h_prox_optval = np.empty(max_iter, dtype=float)
    for k in range(max_iter):
        while True:
            grad_w = np.dot(xtx_N, w) - xty_N
            z = w - grad_w / L
            w_tmp = np.sign(z) * np.maximum(np.abs(z) - lmbd / L, 0)
            w_diff = w_tmp - w
            if f(X, y, w_tmp) <= f(X, y, w) + np.dot(grad_w, w_diff) + L / 2 * np.sum(w_diff ** 2):
                break
            L = L / beta
        w_prev = copy(w)
        w = copy(w_tmp)

        h_prox_optval[k] = objective(X, y, w, lmbd)
        if k > 0 and abs(h_prox_optval[k] - h_prox_optval[k - 1]) < tol:
            break
    return w, h_prox_optval[:k]


def pgd_lasso_path(X, y, lmbds):
    n_samples, n_features = X.shape
    pgd_coefs = np.empty((n_features, len(lmbds)), dtype=float)
    for i, lmbd in enumerate(lmbds):
        w, _ = LASSO_proximal_gradient(X, y, lmbd)
        pgd_coefs[:, i] = w
    return lmbds, pgd_coefs

w = 0
f(w) = f(w) + df(w)*(w_-w) + L/2*(w-w_)**2
=

